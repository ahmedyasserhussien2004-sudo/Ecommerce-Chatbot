"""
Train Module 2 (Sentiment/Emotion Classifier) on dair-ai/emotion by
fine-tuning DistilBERT. Note the domain shift called out in the brief:
this dataset is Twitter text, not customer-support text -- treat
accuracy numbers as a proxy, and spot-check with real support-style
messages afterwards (see the qualitative check at the bottom).

Usage:
    python scripts/train_sentiment_classifier.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from datasets import load_dataset
from src.sentiment_classifier import train, EMOTION_LABELS, DEFAULT_MODEL_DIR


def main():
    print("Downloading dair-ai/emotion ...")
    ds = load_dataset("dair-ai/emotion")

    train_texts, train_labels = ds["train"]["text"], ds["train"]["label"]
    val_texts, val_labels = ds["validation"]["text"], ds["validation"]["label"]

    print(f"Train: {len(train_texts)} rows | Val: {len(val_texts)} rows")
    print(f"Labels: {EMOTION_LABELS}")

    metrics = train(
        train_texts, train_labels, val_texts, val_labels,
        model_dir=DEFAULT_MODEL_DIR, epochs=3, batch_size=16,
    )
    print("\nValidation metrics:", metrics)
    print(f"Model saved to: {DEFAULT_MODEL_DIR}/final")

    # --- Qualitative spot-check on hand-written, customer-support-style
    # messages, to sanity-check the Twitter -> support-chat domain shift
    # called out in the brief. ---
    from src.sentiment_classifier import SentimentClassifier
    clf = SentimentClassifier(DEFAULT_MODEL_DIR)
    samples = [
        "This is the third time my order has been delayed, I am extremely upset.",
        "Thanks so much, that solved my problem perfectly!",
        "Can you tell me the status of my order #48213?",
        "I want a refund immediately, this is unacceptable.",
    ]
    print("\nQualitative spot-check on support-style messages:")
    for s in samples:
        print(f"  {s!r} -> {clf.predict(s)}")


if __name__ == "__main__":
    main()
