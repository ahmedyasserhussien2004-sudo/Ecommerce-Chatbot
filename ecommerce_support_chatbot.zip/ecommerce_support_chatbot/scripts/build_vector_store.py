"""
Build Module 4's retrieval index: embed the Bitext dataset's 'instruction'
column and store it (with the paired 'response', 'category', 'intent' as
payload) in FAISS (default) or Qdrant.

Usage:
    python scripts/build_vector_store.py                # uses VECTOR_BACKEND from .env (default: faiss)
    VECTOR_BACKEND=qdrant python scripts/build_vector_store.py
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dotenv import load_dotenv
from datasets import load_dataset

from src.rag_pipeline import build_faiss_index, build_qdrant_index, DEFAULT_INDEX_DIR

load_dotenv()


def main():
    print("Downloading bitext/Bitext-customer-support-llm-chatbot-training-dataset ...")
    ds = load_dataset("bitext/Bitext-customer-support-llm-chatbot-training-dataset")["train"]

    instructions = ds["instruction"]
    responses = ds["response"]
    categories = ds["category"]
    intents = ds["intent"]

    backend = os.getenv("VECTOR_BACKEND", "faiss")
    print(f"Backend: {backend} | Rows to index: {len(instructions)}")

    if backend == "faiss":
        result = build_faiss_index(instructions, responses, categories, intents, index_dir=DEFAULT_INDEX_DIR)
    elif backend == "qdrant":
        result = build_qdrant_index(instructions, responses, categories, intents)
    else:
        raise ValueError(f"Unknown VECTOR_BACKEND: {backend}")

    print(f"\nIndex built: {result}")
    print("You can now start the API with: uvicorn app.main:app --reload")


if __name__ == "__main__":
    main()
