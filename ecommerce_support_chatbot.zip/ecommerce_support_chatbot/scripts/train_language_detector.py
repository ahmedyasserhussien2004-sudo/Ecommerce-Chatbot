"""
Train Module 1 (Language Detection) on papluca/language-identification.

Usage:
    python scripts/train_language_detector.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from datasets import load_dataset
from src.language_detection import train, DEFAULT_MODEL_DIR


def main():
    print("Downloading papluca/language-identification ...")
    ds = load_dataset("papluca/language-identification")

    train_texts = ds["train"]["text"]
    train_labels = ds["train"]["labels"]
    val_texts = ds["validation"]["text"]
    val_labels = ds["validation"]["labels"]

    print(f"Train: {len(train_texts)} rows | Val: {len(val_texts)} rows")
    print(f"Languages: {sorted(set(train_labels))}")

    metrics = train(train_texts, train_labels, val_texts, val_labels, model_dir=DEFAULT_MODEL_DIR)

    print(f"\nValidation accuracy: {metrics['accuracy']:.4f}")
    print(f"Validation macro-F1: {metrics['macro_f1']:.4f}")
    print(f"Model saved to: {DEFAULT_MODEL_DIR}/language_detector.joblib")

    # Optional: hold out the dataset's test split for a final sanity check
    if "test" in ds:
        test_texts = ds["test"]["text"]
        test_labels = ds["test"]["labels"]
        from src.language_detection import LanguageDetector
        detector = LanguageDetector(DEFAULT_MODEL_DIR)
        correct = sum(
            1 for t, y in zip(test_texts, test_labels) if detector.predict(t)["language"] == y
        )
        print(f"Held-out test accuracy: {correct / len(test_texts):.4f}")


if __name__ == "__main__":
    main()
