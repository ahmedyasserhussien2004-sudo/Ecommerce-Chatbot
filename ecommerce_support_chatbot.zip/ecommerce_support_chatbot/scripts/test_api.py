"""
Quick manual test client for the deployed API.

Usage:
    python scripts/test_api.py
    python scripts/test_api.py "Where is my order #48213?"
"""
import sys
import json
import urllib.request

API_URL = "http://localhost:8000/chat"

DEFAULT_MESSAGES = [
    "Hi there!",
    "Where is my order #48213?",
    "I want to cancel order 55123",
    "This is unacceptable, my package arrived broken and nobody is helping me!!!",
    "Merci beaucoup pour votre aide",
    "Can you recommend a good phone case?",
]


def call(message: str):
    payload = json.dumps({"message": message}).encode("utf-8")
    req = urllib.request.Request(
        API_URL, data=payload, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def main():
    messages = sys.argv[1:] or DEFAULT_MESSAGES
    for msg in messages:
        print(f"\n> {msg}")
        try:
            result = call(msg)
            print(json.dumps(result, indent=2, ensure_ascii=False))
        except Exception as e:
            print(f"Request failed: {e}")


if __name__ == "__main__":
    main()
