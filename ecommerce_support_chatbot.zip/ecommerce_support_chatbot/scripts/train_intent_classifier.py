"""
Train Module 3 (Intent Classifier) on the Bitext customer-support dataset's
gold 'intent' column, and print the routing-category breakdown so you can
sanity-check src.utils.INTENT_ROUTING_MAP against the intents that are
actually present in the data.

Usage:
    python scripts/train_intent_classifier.py
"""
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from datasets import load_dataset
from sklearn.model_selection import train_test_split

from src.intent_classifier import train, DEFAULT_MODEL_DIR
from src.utils import map_intent_to_route, INTENT_ROUTING_MAP


def main():
    print("Downloading bitext/Bitext-customer-support-llm-chatbot-training-dataset ...")
    ds = load_dataset("bitext/Bitext-customer-support-llm-chatbot-training-dataset")["train"]

    texts = ds["instruction"]
    labels = ds["intent"]

    print(f"Total rows: {len(texts)}")
    print(f"Fine-grained intents found: {sorted(set(labels))}")

    # Sanity-check: flag any intent present in the data that ISN'T
    # explicitly listed in INTENT_ROUTING_MAP (it will silently fall back
    # to "out_of_scope" otherwise, which is worth knowing about).
    unmapped = sorted(set(labels) - set(INTENT_ROUTING_MAP.keys()))
    if unmapped:
        print(f"\nWARNING: these intents have no explicit route mapping "
              f"(defaulting to 'out_of_scope'): {unmapped}")
        print("-> update src.utils.INTENT_ROUTING_MAP if any of these should route elsewhere.\n")

    route_counts = Counter(map_intent_to_route(l) for l in labels)
    print("Routing-category distribution:")
    for route, count in route_counts.most_common():
        print(f"  {route:20s} {count:6d}")

    train_texts, val_texts, train_labels, val_labels = train_test_split(
        texts, labels, test_size=0.15, random_state=42, stratify=labels
    )

    metrics = train(train_texts, train_labels, val_texts, val_labels, model_dir=DEFAULT_MODEL_DIR)

    print(f"\nValidation accuracy: {metrics['accuracy']:.4f}")
    print(f"Validation macro-F1: {metrics['macro_f1']:.4f}")
    print(f"Model saved to: {DEFAULT_MODEL_DIR}/intent_classifier.joblib")


if __name__ == "__main__":
    main()
