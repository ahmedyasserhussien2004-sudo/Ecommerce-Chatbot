"""
Fast, dependency-light tests -- only exercise the parts of the codebase
that need nothing but pandas/scikit-learn (no torch, no network, no API
keys). Run with:

    PYTHONPATH=. python -m pytest tests/test_lightweight_modules.py -v

For the transformer + RAG modules, the notebooks (02, 04) double as the
integration test since they require model downloads / a Groq key that
aren't available in every environment.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils import basic_clean, normalize_for_ml, map_intent_to_route
from src.language_detection import train as train_lang
from src.intent_classifier import train as train_intent


def test_basic_clean_strips_urls_and_whitespace():
    text = "Check   https://example.com/order/123   now"
    cleaned = basic_clean(text)
    assert "http" not in cleaned
    assert "  " not in cleaned


def test_normalize_masks_order_numbers():
    cleaned = normalize_for_ml("track order 123456 please!!!")
    assert "123456" not in cleaned
    assert "<ORDER_NUM>" in cleaned


def test_intent_routing_known_and_unknown():
    assert map_intent_to_route("track_order") == "order_status"
    assert map_intent_to_route("complaint") == "complaint"
    assert map_intent_to_route("totally_made_up_intent") == "out_of_scope"


def test_language_detector_end_to_end():
    texts = [
        "hello, where is my order", "hi there how are you",
        "bonjour, ou est ma commande", "salut, merci beaucoup",
    ] * 5
    labels = ["en", "en", "fr", "fr"] * 5
    with tempfile.TemporaryDirectory() as tmp:
        metrics = train_lang(texts, labels, texts, labels, model_dir=Path(tmp))
        assert metrics["accuracy"] > 0.9


def test_intent_classifier_end_to_end():
    texts = [
        "where is my order", "track my package",
        "cancel my order", "please cancel order 123",
        "hi", "hello",
    ] * 5
    labels = ["track_order", "track_order", "cancel_order", "cancel_order", "greet", "greet"] * 5
    with tempfile.TemporaryDirectory() as tmp:
        metrics = train_intent(texts, labels, texts, labels, model_dir=Path(tmp))
        assert metrics["accuracy"] > 0.9
