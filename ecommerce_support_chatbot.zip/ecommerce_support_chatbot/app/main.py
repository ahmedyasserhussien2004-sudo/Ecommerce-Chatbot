"""
FastAPI deployment for the RAG-based e-commerce support chatbot.

Run locally with:
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

All four models (language detector, sentiment classifier, intent
classifier, RAG index + Groq client) are loaded ONCE at startup via the
lifespan handler and kept in memory — each /chat request just runs
inference, it never reloads anything from disk.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.schemas import ChatRequest, ChatResponse
from src.pipeline import ChatbotPipeline

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("support-chatbot")

pipeline_holder: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Loading models (language, sentiment, intent, RAG index)...")
    pipeline_holder["pipeline"] = ChatbotPipeline()
    logger.info("All models loaded. Ready to serve.")
    yield
    pipeline_holder.clear()


app = FastAPI(
    title="E-commerce Support Chatbot API",
    description="RAG-based customer support chatbot: language detection -> "
                 "sentiment classification -> intent routing -> grounded RAG answer.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # tighten this for real deployments
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok", "models_loaded": "pipeline" in pipeline_holder}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    pipeline: ChatbotPipeline = pipeline_holder.get("pipeline")
    if pipeline is None:
        raise HTTPException(status_code=503, detail="Models are still loading, try again shortly.")

    try:
        result = pipeline.handle_message(req.message)
    except Exception as exc:
        logger.exception("Error while handling message")
        raise HTTPException(status_code=500, detail=str(exc))

    sources = result["rag"]["sources"] if result.get("rag") else []
    return ChatResponse(
        response=result["response"],
        route=result["route"],
        language=result["language"],
        sentiment=result["sentiment"],
        intent=result["intent"],
        sources=sources,
    )
