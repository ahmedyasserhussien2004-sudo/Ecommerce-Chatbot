from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, description="Raw customer message")


class LanguageResult(BaseModel):
    language: str
    confidence: float | None = None


class SentimentResult(BaseModel):
    emotion: str
    sentiment: str
    confidence: float


class IntentResult(BaseModel):
    intent: str
    route: str
    confidence: float | None = None


class RAGSource(BaseModel):
    instruction: str
    score: float
    category: str


class ChatResponse(BaseModel):
    response: str
    route: str
    language: LanguageResult
    sentiment: SentimentResult
    intent: IntentResult
    sources: list[RAGSource] = []
