"""
Module 4: Q&A RAG Pipeline
-----------------------------
Retrieval:
  - Embeddings: sentence-transformers/all-MiniLM-L6-v2 (384-dim, fast,
    strong for short-text semantic similarity -> good fit for matching a
    customer's question against the Bitext 'instruction' column).
  - Vector store: FAISS (local, in-process, zero external account needed)
    by default. A Qdrant-cloud backend is also implemented behind the
    same interface (VECTOR_BACKEND=qdrant in .env) in case you want a
    persistent/managed store instead.
  - We embed and index the 'instruction' column only (the customer-style
    question), and keep the paired 'response' as the retrieved payload —
    per the brief: "embed the instructions for retrieval, and inject the
    paired responses into the generation prompt as grounding context."

Generation:
  - Groq-hosted gpt-oss-120b (or gpt-oss-20b) via the official groq
    python client, using the exact system prompt template given in the
    project brief, parameterized with {detected_sentiment}.
"""
from __future__ import annotations

import os
import json
from pathlib import Path
from dataclasses import dataclass

DEFAULT_INDEX_DIR = Path("models/rag_index")
DEFAULT_EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")


@dataclass
class RetrievedChunk:
    instruction: str
    response: str
    category: str
    intent: str
    score: float


# --------------------------------------------------------------------- #
# Index building (run once, offline, via scripts/build_vector_store.py)
# --------------------------------------------------------------------- #
def build_faiss_index(
    instructions: list[str],
    responses: list[str],
    categories: list[str],
    intents: list[str],
    index_dir: Path = DEFAULT_INDEX_DIR,
    embedding_model_name: str = DEFAULT_EMBEDDING_MODEL,
    batch_size: int = 128,
):
    import faiss
    import numpy as np
    from sentence_transformers import SentenceTransformer

    index_dir = Path(index_dir)
    index_dir.mkdir(parents=True, exist_ok=True)

    model = SentenceTransformer(embedding_model_name)
    embeddings = model.encode(
        instructions,
        batch_size=batch_size,
        show_progress_bar=True,
        normalize_embeddings=True,   # so inner product == cosine similarity
        convert_to_numpy=True,
    ).astype("float32")

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)   # cosine similarity via inner product on normalized vecs
    index.add(embeddings)

    faiss.write_index(index, str(index_dir / "faiss.index"))

    payload = [
        {"instruction": i, "response": r, "category": c, "intent": it}
        for i, r, c, it in zip(instructions, responses, categories, intents)
    ]
    with open(index_dir / "payload.jsonl", "w") as f:
        for row in payload:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    with open(index_dir / "config.json", "w") as f:
        json.dump(
            {"embedding_model": embedding_model_name, "dim": dim, "n_vectors": len(payload)},
            f,
            indent=2,
        )

    return {"n_vectors": len(payload), "dim": dim}


def build_qdrant_index(
    instructions: list[str],
    responses: list[str],
    categories: list[str],
    intents: list[str],
    collection_name: str | None = None,
    embedding_model_name: str = DEFAULT_EMBEDDING_MODEL,
    batch_size: int = 128,
):
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, VectorParams, PointStruct
    from sentence_transformers import SentenceTransformer

    collection_name = collection_name or os.getenv("QDRANT_COLLECTION", "support_kb")
    client = QdrantClient(url=os.environ["QDRANT_URL"], api_key=os.environ.get("QDRANT_API_KEY"))

    model = SentenceTransformer(embedding_model_name)
    embeddings = model.encode(
        instructions, batch_size=batch_size, show_progress_bar=True,
        normalize_embeddings=True, convert_to_numpy=True,
    )
    dim = embeddings.shape[1]

    client.recreate_collection(
        collection_name=collection_name,
        vectors_config=VectorParams(size=dim, distance=Distance.COSINE),
    )

    points = [
        PointStruct(
            id=idx,
            vector=embeddings[idx].tolist(),
            payload={
                "instruction": instructions[idx],
                "response": responses[idx],
                "category": categories[idx],
                "intent": intents[idx],
            },
        )
        for idx in range(len(instructions))
    ]
    # upload in chunks
    for start in range(0, len(points), 256):
        client.upsert(collection_name=collection_name, points=points[start:start + 256])

    return {"n_vectors": len(points), "dim": dim, "collection": collection_name}


# --------------------------------------------------------------------- #
# Retrieval + Generation (inference time)
# --------------------------------------------------------------------- #
SYSTEM_PROMPT_TEMPLATE = """You are a helpful, professional customer support assistant \
for an online retailer. Answer the customer's question using ONLY \
the information in the retrieved support responses below. If the \
customer sounds frustrated ({detected_sentiment}), acknowledge \
that before answering. If the retrieved context does not cover \
the question, say so honestly and offer to escalate to a human \
agent rather than guessing."""


class RAGPipeline:
    def __init__(
        self,
        index_dir: Path = DEFAULT_INDEX_DIR,
        backend: str | None = None,
        embedding_model_name: str | None = None,
        groq_model: str | None = None,
        top_k: int = 3,
    ):
        from sentence_transformers import SentenceTransformer

        self.backend = backend or os.getenv("VECTOR_BACKEND", "faiss")
        self.top_k = top_k
        self.index_dir = Path(index_dir)

        cfg_path = self.index_dir / "config.json"
        cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() else {}
        self.embedding_model_name = (
            embedding_model_name or cfg.get("embedding_model", DEFAULT_EMBEDDING_MODEL)
        )
        self.embedder = SentenceTransformer(self.embedding_model_name)

        if self.backend == "faiss":
            import faiss
            self.index = faiss.read_index(str(self.index_dir / "faiss.index"))
            self.payload = [
                json.loads(line) for line in open(self.index_dir / "payload.jsonl")
            ]
        elif self.backend == "qdrant":
            from qdrant_client import QdrantClient
            self.client = QdrantClient(
                url=os.environ["QDRANT_URL"], api_key=os.environ.get("QDRANT_API_KEY")
            )
            self.collection_name = os.getenv("QDRANT_COLLECTION", "support_kb")
        else:
            raise ValueError(f"Unknown VECTOR_BACKEND: {self.backend}")

        from groq import Groq
        self.groq_client = Groq(api_key=os.environ["GROQ_API_KEY"])
        self.groq_model = groq_model or os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")

    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievedChunk]:
        top_k = top_k or self.top_k
        query_vec = self.embedder.encode([query], normalize_embeddings=True, convert_to_numpy=True)

        if self.backend == "faiss":
            scores, indices = self.index.search(query_vec.astype("float32"), top_k)
            chunks = []
            for score, idx in zip(scores[0], indices[0]):
                if idx == -1:
                    continue
                row = self.payload[idx]
                chunks.append(RetrievedChunk(
                    instruction=row["instruction"], response=row["response"],
                    category=row["category"], intent=row["intent"], score=float(score),
                ))
            return chunks

        # qdrant
        hits = self.client.search(
            collection_name=self.collection_name,
            query_vector=query_vec[0].tolist(),
            limit=top_k,
        )
        return [
            RetrievedChunk(
                instruction=h.payload["instruction"], response=h.payload["response"],
                category=h.payload["category"], intent=h.payload["intent"], score=float(h.score),
            )
            for h in hits
        ]

    def build_prompt(self, user_message: str, detected_sentiment: str, chunks: list[RetrievedChunk]):
        system = SYSTEM_PROMPT_TEMPLATE.format(detected_sentiment=detected_sentiment)
        context = "\n\n".join(
            f"[{i+1}] Q: {c.instruction}\nA: {c.response}" for i, c in enumerate(chunks)
        )
        user = f'Context (retrieved past support responses):\n{context}\n\nCustomer question: "{user_message}"'
        return system, user

    def answer(self, user_message: str, detected_sentiment: str = "neutral", top_k: int | None = None) -> dict:
        chunks = self.retrieve(user_message, top_k=top_k)
        system, user = self.build_prompt(user_message, detected_sentiment, chunks)

        completion = self.groq_client.chat.completions.create(
            model=self.groq_model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.2,
            max_tokens=400,
        )
        answer_text = completion.choices[0].message.content

        return {
            "answer": answer_text,
            "sources": [
                {"instruction": c.instruction, "score": c.score, "category": c.category}
                for c in chunks
            ],
        }
