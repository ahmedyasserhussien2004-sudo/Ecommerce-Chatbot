"""
End-to-end orchestration: language -> sentiment -> intent -> routed response.

This is what app/main.py calls on every incoming chat message. Models are
loaded once at process startup (see ChatbotPipeline.__init__) and reused
across requests -- do NOT reload them per-request, that's the #1 way this
kind of deployment gets slow.
"""
from __future__ import annotations

from src.language_detection import LanguageDetector
from src.sentiment_classifier import SentimentClassifier
from src.intent_classifier import IntentClassifier
from src.rag_pipeline import RAGPipeline

SMALLTALK_REPLIES = {
    "greet_like": "Hello! I'm your support assistant — how can I help with your order today?",
    "goodbye_like": "Thanks for reaching out — have a great day!",
    "thanks_like": "You're very welcome! Let me know if there's anything else I can help with.",
}

COMPLAINT_ESCALATION_MSG = (
    "I'm really sorry you've run into this problem, and I understand how "
    "frustrating that is. I don't want to guess at a fix here — I'm flagging "
    "this conversation for priority review by a human agent, who will follow "
    "up with you shortly."
)

OUT_OF_SCOPE_MSG = (
    "I'm not able to help with that from our support knowledge base. "
    "Could you rephrase, or would you like me to connect you with a human agent?"
)


class ChatbotPipeline:
    def __init__(
        self,
        language_model_dir="models/language_detection",
        sentiment_model_dir="models/sentiment",
        intent_model_dir="models/intent",
        rag_index_dir="models/rag_index",
    ):
        self.language_detector = LanguageDetector(language_model_dir)
        self.sentiment_classifier = SentimentClassifier(sentiment_model_dir)
        self.intent_classifier = IntentClassifier(intent_model_dir)
        self.rag = RAGPipeline(index_dir=rag_index_dir)

    def handle_message(self, user_message: str) -> dict:
        lang = self.language_detector.predict(user_message)
        sentiment = self.sentiment_classifier.predict(user_message)
        intent = self.intent_classifier.predict(user_message)

        route = intent["route"]

        if route == "smalltalk":
            response_text = self._smalltalk_reply(intent["intent"])
            rag_result = None
        elif route == "complaint":
            # Priority handling: acknowledge + flag for human escalation,
            # bypassing auto-generated RAG answers entirely (see Guidelines
            # in the brief: route complaints distinctly).
            response_text = COMPLAINT_ESCALATION_MSG
            rag_result = None
        elif route == "out_of_scope":
            response_text = OUT_OF_SCOPE_MSG
            rag_result = None
        else:
            rag_result = self.rag.answer(user_message, detected_sentiment=sentiment["sentiment"])
            response_text = rag_result["answer"]
            # Extra safety net: even for RAG-routed intents, if the
            # sentiment model independently flags strong negativity,
            # prepend an apology before the grounded answer.
            if sentiment["sentiment"] == "negative":
                response_text = (
                    "I'm sorry for the trouble — let's get this sorted out. " + response_text
                )

        return {
            "user_message": user_message,
            "language": lang,
            "sentiment": sentiment,
            "intent": intent,
            "route": route,
            "response": response_text,
            "rag": rag_result,
        }

    @staticmethod
    def _smalltalk_reply(fine_intent: str) -> str:
        if fine_intent in ("goodbye",):
            return SMALLTALK_REPLIES["goodbye_like"]
        if fine_intent in ("thank_you",):
            return SMALLTALK_REPLIES["thanks_like"]
        return SMALLTALK_REPLIES["greet_like"]
