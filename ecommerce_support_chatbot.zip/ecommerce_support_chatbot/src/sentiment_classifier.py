"""
Module 2: Sentiment / Emotion Classifier
-------------------------------------------
Transformer fine-tuning (DistilBERT) rather than a from-scratch RNN.
Rationale (be ready to defend this choice in the assessment):
  - dair-ai/emotion is only ~20k short texts — plenty for fine-tuning a
    pretrained encoder's classification head, but on the small side for
    training an RNN's embeddings from scratch to reach comparable
    accuracy.
  - DistilBERT is 40% smaller / ~60% faster than BERT with ~97% of its
    language-understanding performance, which matters because this also
    needs to run inside a synchronous FastAPI request path.
  - Pretrained subword tokenization + contextual embeddings handle the
    negation / sarcasm cases ("not happy at all") that a small
    from-scratch BiLSTM tends to struggle with on this little data.
  - An LSTM/BiLSTM alternative (`build_bilstm_sketch` below, commented)
    is included as a documented fallback in case DistilBERT is judged
    too heavy for the deployment environment.

We fine-tune on the ORIGINAL 6 emotion labels (sadness, joy, love, anger,
fear, surprise) and only collapse to the 3-bucket
negative/neutral/positive scheme at INFERENCE time via
src.utils.EMOTION_TO_SENTIMENT. Training on 6 classes keeps more signal
for the model to learn from than immediately collapsing to 3; the
collapse is a cheap, deterministic mapping afterwards, same pattern as
the intent classifier.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from src.utils import basic_clean, EMOTION_TO_SENTIMENT

DEFAULT_MODEL_DIR = Path("models/sentiment")
BASE_CHECKPOINT = "distilbert-base-uncased"
EMOTION_LABELS = ["sadness", "joy", "love", "anger", "fear", "surprise"]


def train(
    train_texts,
    train_labels,          # ints 0..5, matching EMOTION_LABELS order
    val_texts,
    val_labels,
    model_dir: Path = DEFAULT_MODEL_DIR,
    epochs: int = 3,
    batch_size: int = 16,
    lr: float = 2e-5,
) -> dict:
    """Fine-tunes DistilBERT for sequence classification.

    Heavy imports (torch/transformers) are done inside the function so
    the rest of the codebase can be imported/tested without requiring a
    GPU-capable torch install.
    """
    import torch
    from datasets import Dataset
    from sklearn.metrics import accuracy_score, f1_score
    from transformers import (
        AutoTokenizer,
        AutoModelForSequenceClassification,
        TrainingArguments,
        Trainer,
        DataCollatorWithPadding,
    )

    model_dir = Path(model_dir)
    model_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(BASE_CHECKPOINT)
    model = AutoModelForSequenceClassification.from_pretrained(
        BASE_CHECKPOINT, num_labels=len(EMOTION_LABELS)
    )

    def tokenize(batch):
        cleaned = [basic_clean(t) for t in batch["text"]]
        return tokenizer(cleaned, truncation=True, max_length=64)

    train_ds = Dataset.from_dict({"text": train_texts, "label": train_labels}).map(
        tokenize, batched=True
    )
    val_ds = Dataset.from_dict({"text": val_texts, "label": val_labels}).map(
        tokenize, batched=True
    )

    collator = DataCollatorWithPadding(tokenizer=tokenizer)

    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        preds = np.argmax(logits, axis=-1)
        return {
            "accuracy": accuracy_score(labels, preds),
            "macro_f1": f1_score(labels, preds, average="macro"),
        }

    args = TrainingArguments(
        output_dir=str(model_dir / "checkpoints"),
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size * 2,
        learning_rate=lr,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        logging_steps=50,
        report_to=[],
        fp16=torch.cuda.is_available(),
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=collator,
        compute_metrics=compute_metrics,
    )
    trainer.train()
    metrics = trainer.evaluate()

    # Save final artifacts to a clean, stable path (not the checkpoints dir)
    final_dir = model_dir / "final"
    trainer.save_model(str(final_dir))
    tokenizer.save_pretrained(str(final_dir))

    with open(model_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2, default=float)

    return metrics


class SentimentClassifier:
    """Inference-time wrapper. Loads the fine-tuned DistilBERT and
    exposes both the fine-grained emotion and the collapsed 3-bucket
    sentiment used for routing/tone."""

    def __init__(self, model_dir: Path = DEFAULT_MODEL_DIR, device: str | None = None):
        import torch
        from transformers import AutoTokenizer, AutoModelForSequenceClassification

        self.model_dir = Path(model_dir) / "final"
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(str(self.model_dir))
        self.model = AutoModelForSequenceClassification.from_pretrained(str(self.model_dir))
        self.model.to(self.device)
        self.model.eval()
        self._torch = torch

    def predict(self, text: str) -> dict:
        torch = self._torch
        cleaned = basic_clean(text)
        inputs = self.tokenizer(cleaned, return_tensors="pt", truncation=True, max_length=64)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        with torch.no_grad():
            logits = self.model(**inputs).logits
            probs = torch.softmax(logits, dim=-1)[0].cpu().numpy()
        idx = int(np.argmax(probs))
        emotion = EMOTION_LABELS[idx]
        sentiment = EMOTION_TO_SENTIMENT[emotion]
        return {
            "emotion": emotion,
            "sentiment": sentiment,
            "confidence": float(probs[idx]),
        }


# ---------------------------------------------------------------------------
# Documented fallback: a from-scratch BiLSTM, in case a lighter / fully
# from-scratch model is preferred over fine-tuning a pretrained transformer.
# Not wired into the pipeline by default -- swap SentimentClassifier for
# this if you go that route, and update scripts/train_sentiment_classifier.py
# accordingly.
# ---------------------------------------------------------------------------
def build_bilstm_sketch(vocab_size: int, embed_dim: int = 128, hidden_dim: int = 128, num_classes: int = 6):
    """Returns an untrained torch.nn.Module. Left as a sketch/fallback —
    see the module docstring for why DistilBERT is the default instead."""
    import torch
    import torch.nn as nn

    class BiLSTMClassifier(nn.Module):
        def __init__(self):
            super().__init__()
            self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
            self.lstm = nn.LSTM(
                embed_dim, hidden_dim, batch_first=True, bidirectional=True
            )
            self.dropout = nn.Dropout(0.3)
            self.fc = nn.Linear(hidden_dim * 2, num_classes)

        def forward(self, input_ids, lengths):
            embedded = self.embedding(input_ids)
            packed = nn.utils.rnn.pack_padded_sequence(
                embedded, lengths.cpu(), batch_first=True, enforce_sorted=False
            )
            _, (hidden, _) = self.lstm(packed)
            # concat last forward + backward hidden states
            h = self.dropout(torch.cat([hidden[-2], hidden[-1]], dim=1))
            return self.fc(h)

    return BiLSTMClassifier()
