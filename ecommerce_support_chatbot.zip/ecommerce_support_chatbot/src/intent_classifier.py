"""
Module 3: Intent Classifier
-----------------------------
Supervised classifier trained directly on the Bitext dataset's gold
'intent' column (27 fine-grained intents), then mapped at inference time
to the 7 routing categories defined in the project brief (see
src.utils.INTENT_ROUTING_MAP). We train on the *fine-grained* label
rather than the coarse one because:
  - It's the label the dataset actually gives us (no manual re-labeling
    needed), so it's a clean supervised problem, not zero/few-shot.
  - Fine-grained predictions are still useful on their own (e.g. for
    logging/analytics), and collapsing to the 7 routes is a cheap,
    deterministic lookup after prediction — no information is lost by
    training coarse-first.

Model: TF-IDF (word uni+bi-grams) + LinearSVC, same family as the
language detector but tuned for word-level features since customer
intent is carried by vocabulary/phrasing, not orthography.
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, f1_score
from sklearn.pipeline import Pipeline

from src.utils import normalize_for_ml, map_intent_to_route

DEFAULT_MODEL_DIR = Path("models/intent")


def build_pipeline() -> Pipeline:
    vectorizer = TfidfVectorizer(
        analyzer="word",
        ngram_range=(1, 2),
        min_df=2,
        max_features=40_000,
        sublinear_tf=True,
    )
    # LogisticRegression gives calibrated-ish probabilities out of the box
    # (useful for a confidence threshold before auto-routing) and handles
    # the class imbalance across 27 intents well with class_weight.
    clf = LogisticRegression(
        max_iter=2000, class_weight="balanced", C=2.0
    )
    return Pipeline([("tfidf", vectorizer), ("clf", clf)])


def train(
    train_texts,
    train_labels,
    val_texts=None,
    val_labels=None,
    model_dir: Path = DEFAULT_MODEL_DIR,
) -> dict:
    model_dir = Path(model_dir)
    model_dir.mkdir(parents=True, exist_ok=True)

    train_texts_clean = [normalize_for_ml(t) for t in train_texts]
    pipeline = build_pipeline()
    pipeline.fit(train_texts_clean, train_labels)

    metrics = {}
    if val_texts is not None and val_labels is not None:
        val_texts_clean = [normalize_for_ml(t) for t in val_texts]
        preds = pipeline.predict(val_texts_clean)
        metrics = {
            "accuracy": accuracy_score(val_labels, preds),
            "macro_f1": f1_score(val_labels, preds, average="macro"),
            "report": classification_report(val_labels, preds, output_dict=True),
        }

    joblib.dump(pipeline, model_dir / "intent_classifier.joblib")
    with open(model_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2, default=float)

    return metrics


class IntentClassifier:
    def __init__(self, model_dir: Path = DEFAULT_MODEL_DIR):
        self.model_dir = Path(model_dir)
        self.pipeline: Pipeline = joblib.load(self.model_dir / "intent_classifier.joblib")

    def predict(self, text: str) -> dict:
        cleaned = normalize_for_ml(text)
        fine_label = self.pipeline.predict([cleaned])[0]
        confidence = None
        if hasattr(self.pipeline, "predict_proba"):
            proba = self.pipeline.predict_proba([cleaned])[0]
            confidence = float(max(proba))
        route = map_intent_to_route(fine_label)
        return {
            "intent": fine_label,
            "route": route,
            "confidence": confidence,
        }


if __name__ == "__main__":
    texts = [
        "where is my order", "track my package please",
        "cancel my order now", "I want to cancel order 12345",
        "how do I get a refund", "refund my last payment",
        "hi", "hello there", "thanks a lot", "thank you so much",
        "this is unacceptable, terrible service", "I want to complain about my order",
    ] * 3
    labels = [
        "track_order", "track_order",
        "cancel_order", "cancel_order",
        "get_refund", "get_refund",
        "greet", "greet", "thank_you", "thank_you",
        "complaint", "complaint",
    ] * 3
    m = train(texts, labels, texts, labels, model_dir=Path("/tmp/intent_smoke"))
    print("Smoke-test accuracy:", m["accuracy"])
