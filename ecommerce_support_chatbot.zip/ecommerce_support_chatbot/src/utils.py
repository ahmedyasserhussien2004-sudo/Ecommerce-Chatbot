"""
Shared utilities used across all four modules.

Kept deliberately lightweight (regex + stdlib) so every module can import
this without pulling in heavy dependencies just for text cleaning.
"""
from __future__ import annotations

import re
import string
import unicodedata

_WHITESPACE_RE = re.compile(r"\s+")
_URL_RE = re.compile(r"https?://\S+|www\.\S+")
_EMAIL_RE = re.compile(r"\S+@\S+\.\S+")
_ORDER_NUM_RE = re.compile(r"\b#?\d{4,}\b")


def basic_clean(text: str) -> str:
    """Light, language-agnostic cleanup. Safe to use before language
    detection since it does NOT lowercase or strip accents (both are
    meaningful signals for language ID)."""
    if not isinstance(text, str):
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = _URL_RE.sub(" ", text)
    text = _EMAIL_RE.sub(" ", text)
    text = _WHITESPACE_RE.sub(" ", text).strip()
    return text


def normalize_for_ml(text: str, mask_order_numbers: bool = True) -> str:
    """Heavier normalization for the sentiment/intent classifiers, where
    case and exact numbers add noise rather than signal.

    mask_order_numbers=True replaces long digit sequences (order/invoice
    numbers) with a placeholder token so the classifier generalizes
    instead of memorizing specific IDs.
    """
    text = basic_clean(text)
    text = text.lower()
    if mask_order_numbers:
        text = _ORDER_NUM_RE.sub(" <ORDER_NUM> ", text)
    # Collapse repeated punctuation used for emphasis ("!!!", "???") down
    # to a single mark, but keep a flag-friendly trace via a token so the
    # sentiment model can still learn that repetition correlates with
    # frustration.
    text = re.sub(r"([!?.])\1{1,}", r"\1 <REPEAT_PUNCT> ", text)
    text = _WHITESPACE_RE.sub(" ", text).strip()
    return text


def strip_punct(text: str) -> str:
    return text.translate(str.maketrans("", "", string.punctuation))


# --- Intent taxonomy: mapping from the Bitext dataset's 27 fine-grained
# intents down to the 7 routing categories defined in the project brief. ---
INTENT_ROUTING_MAP = {
    # greeting / goodbye / gratitude
    "greet": "smalltalk",
    "goodbye": "smalltalk",
    "thank_you": "smalltalk",
    # order_status
    "track_order": "order_status",
    "delivery_options": "order_status",
    "delivery_period": "order_status",
    "track_refund": "order_status",
    # order_management
    "cancel_order": "order_management",
    "change_order": "order_management",
    "place_order": "order_management",
    "change_shipping_address": "order_management",
    "set_up_shipping_address": "order_management",
    # billing_and_refunds
    "check_invoice": "billing_and_refunds",
    "get_invoice": "billing_and_refunds",
    "get_refund": "billing_and_refunds",
    "payment_issue": "billing_and_refunds",
    "check_payment_methods": "billing_and_refunds",
    "check_refund_policy": "billing_and_refunds",
    "cancel_refund": "billing_and_refunds",
    # account_management
    "create_account": "account_management",
    "edit_account": "account_management",
    "delete_account": "account_management",
    "switch_account": "account_management",
    "recover_password": "account_management",
    "registration_problems": "account_management",
    # complaint (priority handling)
    "complaint": "complaint",
    "review": "complaint",
    "contact_customer_service": "complaint",
    "contact_human_agent": "complaint",
    # newsletter -> treated as account/preferences, low priority
    "newsletter_subscription": "account_management",
}

ROUTING_CATEGORIES = [
    "smalltalk",
    "order_status",
    "order_management",
    "billing_and_refunds",
    "account_management",
    "complaint",
    "out_of_scope",
]


def map_intent_to_route(fine_grained_intent: str) -> str:
    return INTENT_ROUTING_MAP.get(fine_grained_intent, "out_of_scope")


SENTIMENT_LABELS = ["negative", "neutral", "positive"]

# dair-ai/emotion's 6 labels -> 3-bucket sentiment used for routing.
EMOTION_TO_SENTIMENT = {
    "sadness": "negative",
    "anger": "negative",
    "fear": "negative",
    "joy": "positive",
    "love": "positive",
    "surprise": "neutral",
}
