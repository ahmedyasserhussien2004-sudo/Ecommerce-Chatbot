"""
Module 1: Language Detection
-----------------------------
Traditional-NLP multi-class classifier: TF-IDF over CHARACTER n-grams
(not word n-grams) + a linear classifier.

Why char n-grams instead of word n-grams / Count Vectorizer on words:
  - Works even on short customer messages ("merci", "grazie mille").
  - Captures sub-word morphology that is highly language-specific
    (accents, digraphs, endings) without needing a huge vocabulary.
  - Robust to typos and mixed-case input, unlike word-level features.
  - This is the standard, well-understood approach for language ID
    (same idea used by langdetect/fastText's char n-gram models) and is
    easy to explain and defend in the oral assessment.

Model: LinearSVC (via CalibratedClassifierCV so we still get usable
probability/confidence scores) — fast to train on 90k rows, strong on
high-dimensional sparse TF-IDF features, and a defensible, explainable
choice for a "traditional ML" requirement.
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, accuracy_score, f1_score
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from src.utils import basic_clean

DEFAULT_MODEL_DIR = Path("models/language_detection")


def build_pipeline() -> Pipeline:
    vectorizer = TfidfVectorizer(
        analyzer="char_wb",       # char n-grams within word boundaries
        ngram_range=(1, 4),
        min_df=2,
        max_features=60_000,
        sublinear_tf=True,
    )
    base_clf = LinearSVC(C=1.0, class_weight="balanced")
    # Wrap in a calibrated classifier so predict_proba is available for a
    # confidence score we can surface to the pipeline / API response.
    clf = CalibratedClassifierCV(base_clf, method="sigmoid", cv=3)
    return Pipeline([("tfidf", vectorizer), ("clf", clf)])


def train(
    train_texts,
    train_labels,
    val_texts=None,
    val_labels=None,
    model_dir: Path = DEFAULT_MODEL_DIR,
) -> dict:
    """Fit the pipeline and persist it. Returns a metrics dict."""
    model_dir = Path(model_dir)
    model_dir.mkdir(parents=True, exist_ok=True)

    train_texts = [basic_clean(t) for t in train_texts]
    pipeline = build_pipeline()
    pipeline.fit(train_texts, train_labels)

    metrics = {}
    if val_texts is not None and val_labels is not None:
        val_texts_clean = [basic_clean(t) for t in val_texts]
        preds = pipeline.predict(val_texts_clean)
        metrics = {
            "accuracy": accuracy_score(val_labels, preds),
            "macro_f1": f1_score(val_labels, preds, average="macro"),
            "report": classification_report(val_labels, preds, output_dict=True),
        }

    joblib.dump(pipeline, model_dir / "language_detector.joblib")
    with open(model_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2, default=float)

    return metrics


class LanguageDetector:
    """Inference-time wrapper used by the pipeline / API."""

    def __init__(self, model_dir: Path = DEFAULT_MODEL_DIR):
        self.model_dir = Path(model_dir)
        self.pipeline: Pipeline = joblib.load(self.model_dir / "language_detector.joblib")

    def predict(self, text: str) -> dict:
        cleaned = basic_clean(text)
        label = self.pipeline.predict([cleaned])[0]
        confidence = None
        if hasattr(self.pipeline, "predict_proba"):
            proba = self.pipeline.predict_proba([cleaned])[0]
            confidence = float(max(proba))
        return {"language": label, "confidence": confidence}


if __name__ == "__main__":
    # Smoke test with a tiny synthetic set so the module can be sanity
    # checked without downloading the full dataset. Real training happens
    # in scripts/train_language_detector.py against papluca/language-identification.
    texts = [
        "hello, where is my order", "hi there how are you",
        "bonjour, où est ma commande", "salut, merci beaucoup",
        "hola, ¿dónde está mi pedido?", "gracias por su ayuda",
    ]
    labels = ["en", "en", "fr", "fr", "es", "es"]
    m = train(texts, labels, texts, labels, model_dir=Path("/tmp/lang_smoke"))
    print("Smoke-test metrics:", m.get("accuracy"))
